import { defaultTheme } from './default';

export const themes = {
  default: defaultTheme,
};
