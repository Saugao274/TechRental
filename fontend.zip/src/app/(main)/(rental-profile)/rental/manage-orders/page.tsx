import ManageProducts from '@/components/modules/Rental/ManageProducts'
import React from 'react'

export default function RentalIdentificationPage() {
    return <ManageProducts />
}
