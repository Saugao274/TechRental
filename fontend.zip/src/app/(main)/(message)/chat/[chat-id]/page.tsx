import ChatModal from '@/components/core/elements/ChatModal'
import MessageModule from '@/components/modules/Message'
import React from 'react'

export default function ChatRoomPage() {
    return <MessageModule />
}
