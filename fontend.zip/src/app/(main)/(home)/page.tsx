import Home from '@/components/modules/Home'

function Page() {
    return <Home />
}

export default Page
