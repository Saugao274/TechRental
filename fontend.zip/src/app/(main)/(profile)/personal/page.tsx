import PersonalProfile from '@/components/modules/Profile/Personal'
import React from 'react'

export default function ProfileUserPage() {
    return <PersonalProfile />
}
