import UpdateProfile from '@/components/modules/Profile/UpdateProfile'
import React from 'react'
export default function PersonalUpdateInforPage() {
    return <UpdateProfile />
}
