import ShopCart from '@/components/modules/ShopCart'
import React from 'react'

export default function ShopCartPage() {
    return <ShopCart />
}
