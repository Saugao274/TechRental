import ChangePassword from '@/components/modules/Profile/ChangePassword'
import React from 'react'

export default function PersonalPasswordPage() {
  return (
    <ChangePassword/>
  )
}
