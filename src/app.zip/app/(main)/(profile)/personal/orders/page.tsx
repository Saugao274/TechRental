import OrderManagement from '@/components/modules/Profile/Personal/OrderManagement'
import React from 'react'

export default function PersonalOrdersPage() {
  return (
    <OrderManagement/>
  )
}
