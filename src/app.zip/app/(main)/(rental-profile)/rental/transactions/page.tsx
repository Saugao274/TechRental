import TransactionStatistics from '@/components/modules/Rental/TransactionStatistics'
import React from 'react'

const TransactionPage = () => {
    return <TransactionStatistics/>
}

export default TransactionPage
