import Products from '@/components/modules/Products'
import React from 'react'

export default function ProductPage() {
    return <Products />
}
