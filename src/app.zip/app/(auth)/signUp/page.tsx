import SignUpModule from '@/components/modules/SignUp'
import React from 'react'

export default function SignUpPage() {
  return (
    <SignUpModule/>
  )
}
