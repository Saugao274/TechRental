import SignIn from '@/components/modules/SignIn'

function Page() {
    return <SignIn />
}

export default Page
